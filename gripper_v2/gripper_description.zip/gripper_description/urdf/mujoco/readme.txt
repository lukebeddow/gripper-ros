To create mujoco compliant xml, run the bash script:

$ ./generate_xml.sh

Then, to visualise in Mujoco, run:

$ ./simulate panda_and_gripper_mujoco.xml
